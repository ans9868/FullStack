import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b7f440bf"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=b7f440bf"; const ReactDOM = __vite__cjsImport1_reactDom_client.__esModule ? __vite__cjsImport1_reactDom_client.default : __vite__cjsImport1_reactDom_client;
import App from "/src/App.jsx?t=1719968354052";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=b7f440bf";
import store from "/src/store.js?t=1719892586307";
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(Provider, { store, children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/main.jsx",
  lineNumber: 6,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/main.jsx",
  lineNumber: 5,
  columnNumber: 61
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7QUFSSixPQUFPQSxjQUFjO0FBQ3JCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsZ0JBQWdCO0FBRXpCLE9BQU9DLFdBQVc7QUFFbEJILFNBQVNJLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFDLEVBQUVDLE9BQ25ELHVCQUFDLFlBQVMsT0FDUixpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQSxDQUNGIiwibmFtZXMiOlsiUmVhY3RET00iLCJBcHAiLCJQcm92aWRlciIsInN0b3JlIiwiY3JlYXRlUm9vdCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuXG5pbXBvcnQgc3RvcmUgZnJvbSAnLi9zdG9yZS5qcydcblxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKS5yZW5kZXIoXG4gIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxuICAgIDxBcHAgLz5cbiAgPC9Qcm92aWRlcj4sXG4pXG4iXSwiZmlsZSI6Ii9Vc2Vycy91c2VyL0Rlc2t0b3AvZnVsbFN0YWNrLzctUm91dGVyLUNvc3R1bUhvb2tzLUNTUy1XZWJwYWNrLzcuMTAtUmVkdXgtUmVmYWN0b3IvZnJvbnRlbmQvc3JjL21haW4uanN4In0=