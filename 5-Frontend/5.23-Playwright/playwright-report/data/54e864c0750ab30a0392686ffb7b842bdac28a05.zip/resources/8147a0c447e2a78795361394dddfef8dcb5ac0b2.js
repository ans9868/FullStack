import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b7f440bf"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b7f440bf"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx?t=1719892652946";
import BlogForm from "/src/components/BlogForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=b7f440bf";
import { postNotification } from "/src/reducers/notificationReducer.js?t=1719892586307";
const App = () => {
  _s();
  const dispatch = useDispatch();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const blogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
    console.log(blogs);
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("wrong credentials");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleDelete = async (blogObject) => {
    console.log("delete triggered");
    try {
      await blogService.remove(blogObject);
      const blogIndex = blogs.filter((blog) => blog.id === blogObject.id);
      if (blogIndex !== -1) {
        const updatedBlogs = blogs.filter((blog) => blog.id !== blogObject.id);
        setBlogs(updatedBlogs);
      } else {
        console.log("Some but happened deleting the object properly");
      }
    } catch (error) {
      setErrorMessage("Blog unable to be deleted");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLogout = async (event) => {
    window.localStorage.removeItem("loggedBlogappUser");
    window.localStorage.clear();
  };
  const handleAddBlog = async (blogObject) => {
    blogFormRef.current.toggleVisibility();
    try {
      const responseBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(responseBlog));
      dispatch(postNotification({
        message: "A new blog was added!"
      }));
    } catch (exception) {
      dispatch(postNotification({
        message: "Blog unable to be posted"
      }));
    }
  };
  const handleAddLike = async (blogObject) => {
    try {
      const updatedBlog = await blogService.addLike(blogObject);
      const index = blogs.findIndex((blog) => blog.id === updatedBlog.id);
      if (index !== -1) {
        const updatedBlogs = [...blogs];
        updatedBlogs[index] = updatedBlog;
        setBlogs(updatedBlogs);
      } else {
        throw errorMessage("Error in adding like to blog");
      }
    } catch (error) {
      dispatch(postNotification({
        message: "Error: unable to add like"
      }));
      console.error("Error in adding like to blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login Form" }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "username", value: username, name: "Username", onChange: ({
          target
        }) => setUsername(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
          lineNumber: 113,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, name: "Password", onChange: ({
          target
        }) => setPassword(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "loginButton", type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 108,
    columnNumber: 27
  }, this);
  const displayBlogs = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 129,
      columnNumber: 7
    }, this),
    blogs.sort((a, b) => b.likes - a.likes).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, handleAddLike, handleDelete }, blog.id, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 131,
      columnNumber: 18
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 128,
    columnNumber: 30
  }, this);
  const logoutForm = () => /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogout, children: /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Logout" }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 135,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 134,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 133,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Notification, {}, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 139,
      columnNumber: 7
    }, this),
    user ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: handleAddBlog }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
        lineNumber: 142,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
        lineNumber: 141,
        columnNumber: 11
      }, this),
      displayBlogs(),
      logoutForm()
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
      lineNumber: 140,
      columnNumber: 15
    }, this) : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx",
    lineNumber: 138,
    columnNumber: 10
  }, this);
};
_s(App, "ZdEPdIZFhBSCVyu7hIaALEBPdGY=", false, function() {
  return [useDispatch];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0hNLFNBeURFLFVBekRGOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRITixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFFekIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBRXRCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx3QkFBd0I7QUFFakMsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU1DLFdBQVdKLFlBQVk7QUFFN0IsUUFBTSxDQUFDSyxPQUFPQyxRQUFRLElBQUlmLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0IsVUFBVUMsV0FBVyxJQUFJbkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29CLE1BQU1DLE9BQU8sSUFBSXJCLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUFTLElBQUk7QUFFckQsUUFBTXdCLGNBQWN0QixPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZEcsZ0JBQVlxQixPQUFPLEVBQUVDLEtBQU1aLFlBQVVDLFNBQVNELE1BQUssQ0FBQztBQUNwRGEsWUFBUUMsSUFBSWQsS0FBSztBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMYixZQUFVLE1BQU07QUFDZCxVQUFNNEIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVQsUUFBT2EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1IsY0FBUUQsS0FBSTtBQUNaaEIsa0JBQVkrQixTQUFTZixNQUFLZ0IsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1uQixRQUFPLE1BQU1mLGFBQWFtQyxNQUFNO0FBQUEsUUFDcEN4QjtBQUFBQSxRQUNBRTtBQUFBQSxNQUNGLENBQUM7QUFFRFksYUFBT0MsYUFBYVUsUUFBUSxxQkFBcUJSLEtBQUtTLFVBQVV0QixLQUFJLENBQUM7QUFDckVoQixrQkFBWStCLFNBQVNmLE1BQUtnQixLQUFLO0FBQy9CZixjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVN3QixXQUFXO0FBQ2xCcEIsc0JBQWdCLG1CQUFtQjtBQUNuQ3FCLGlCQUFXLE1BQU07QUFDZnJCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0IsZUFBZSxPQUFPQyxlQUFlO0FBQ3pDbkIsWUFBUUMsSUFBSSxrQkFBa0I7QUFDOUIsUUFBSTtBQUNGLFlBQU14QixZQUFZMkMsT0FBT0QsVUFBVTtBQUNuQyxZQUFNRSxZQUFZbEMsTUFBTW1DLE9BQVFDLFVBQVNBLEtBQUtDLE9BQU9MLFdBQVdLLEVBQUU7QUFDbEUsVUFBSUgsY0FBYyxJQUFJO0FBQ3BCLGNBQU1JLGVBQWV0QyxNQUFNbUMsT0FBUUMsVUFBU0EsS0FBS0MsT0FBT0wsV0FBV0ssRUFBRTtBQUNyRXBDLGlCQUFTcUMsWUFBWTtBQUFBLE1BQ3ZCLE9BQU87QUFDTHpCLGdCQUFRQyxJQUFJLGdEQUFnRDtBQUFBLE1BQzlEO0FBQUEsSUFDRixTQUFTeUIsT0FBTztBQUNkOUIsc0JBQWdCLDJCQUEyQjtBQUMzQ3FCLGlCQUFXLE1BQU07QUFDZnJCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxRQUFNK0IsZUFBZSxPQUFPaEIsVUFBVTtBQUNwQ1IsV0FBT0MsYUFBYXdCLFdBQVcsbUJBQW1CO0FBQ2xEekIsV0FBT0MsYUFBYXlCLE1BQU07QUFBQSxFQUM1QjtBQUVBLFFBQU1DLGdCQUFnQixPQUFPWCxlQUFlO0FBQzFDdEIsZ0JBQVlrQyxRQUFRQyxpQkFBaUI7QUFFckMsUUFBSTtBQUNGLFlBQU1DLGVBQWUsTUFBTXhELFlBQVl5RCxPQUFPZixVQUFVO0FBRXhEL0IsZUFBU0QsTUFBTWdELE9BQU9GLFlBQVksQ0FBQztBQUVuQy9DLGVBQVNILGlCQUFpQjtBQUFBLFFBQUVxRCxTQUFTO0FBQUEsTUFBd0IsQ0FBQyxDQUFDO0FBQUEsSUFDakUsU0FBU3BCLFdBQVc7QUFDbEI5QixlQUFTSCxpQkFBaUI7QUFBQSxRQUFFcUQsU0FBUztBQUFBLE1BQTJCLENBQUMsQ0FBQztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGdCQUFnQixPQUFPbEIsZUFBZTtBQUMxQyxRQUFJO0FBQ0YsWUFBTW1CLGNBQWMsTUFBTTdELFlBQVk4RCxRQUFRcEIsVUFBVTtBQUN4RCxZQUFNcUIsUUFBUXJELE1BQU1zRCxVQUFXbEIsVUFBU0EsS0FBS0MsT0FBT2MsWUFBWWQsRUFBRTtBQUVsRSxVQUFJZ0IsVUFBVSxJQUFJO0FBQ2hCLGNBQU1mLGVBQWUsQ0FBQyxHQUFHdEMsS0FBSztBQUM5QnNDLHFCQUFhZSxLQUFLLElBQUlGO0FBQ3RCbEQsaUJBQVNxQyxZQUFZO0FBQUEsTUFDdkIsT0FBTztBQUVMLGNBQU05QixhQUFhLDhCQUE4QjtBQUFBLE1BRW5EO0FBQUEsSUFDRixTQUFTK0IsT0FBTztBQUNkeEMsZUFBU0gsaUJBQWlCO0FBQUEsUUFBRXFELFNBQVM7QUFBQSxNQUE0QixDQUFDLENBQUM7QUFDbkVwQyxjQUFRMEIsTUFBTSw4QkFBOEI7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsWUFBWUEsTUFDaEIsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFDZCx1QkFBQyxVQUFLLFVBQVVoQyxhQUNkO0FBQUEsNkJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRix1QkFBQyxXQUNDLGVBQVksWUFDWixNQUFLLFlBQ0wsT0FBT3JCLFVBQ1AsTUFBTSxZQUNOLFVBQVUsQ0FBQztBQUFBLFVBQUVzRDtBQUFBQSxRQUFPLE1BQU1yRCxZQUFZcUQsT0FBT0MsS0FBSyxLQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3NEO0FBQUEsV0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsZUFBWSxZQUNaLE1BQUssWUFDTCxPQUFPckQsVUFDUCxNQUFNLFlBQ04sVUFBVSxDQUFDO0FBQUEsVUFBRW9EO0FBQUFBLFFBQU8sTUFBTW5ELFlBQVltRCxPQUFPQyxLQUFLLEtBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLc0Q7QUFBQSxXQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sZUFBWSxlQUFjLE1BQUssVUFBUSxxQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLE9BMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFHRixRQUFNQyxlQUFlQSxNQUNuQix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNSMUQsTUFDRTJELEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxFQUNoQ0MsSUFBSzNCLFVBQ0osdUJBQUMsUUFFQyxNQUNBLGVBQ0EsZ0JBSEtBLEtBQUtDLElBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUk2QixDQUU5QjtBQUFBLE9BWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBR0YsUUFBTTJCLGFBQWFBLE1BQ2pCLHVCQUFDLFNBQ0MsaUNBQUMsVUFBSyxVQUFVeEIsY0FDZCxpQ0FBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFHRixTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxJQUNabEMsT0FDQyxtQ0FDRTtBQUFBLDZCQUFDLGFBQVUsYUFBWSxZQUFXLEtBQUtJLGFBQ3JDLGlDQUFDLFlBQVMsWUFBWWlDLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NlLGFBQWE7QUFBQSxNQUNiTSxXQUFXO0FBQUEsU0FMZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUEsSUFFQVQsVUFBVTtBQUFBLE9BWGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ3pELEdBL0tLRCxLQUFHO0FBQUEsVUFDVUYsV0FBVztBQUFBO0FBQUFzRSxLQUR4QnBFO0FBaUxOLGVBQWVBO0FBRWYsSUFBQW9FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkJsb2ciLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIk5vdGlmaWNhdGlvbiIsIkJsb2dGb3JtIiwiVG9nZ2xhYmxlIiwidXNlRGlzcGF0Y2giLCJwb3N0Tm90aWZpY2F0aW9uIiwiQXBwIiwiX3MiLCJkaXNwYXRjaCIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwiYmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwiY29uc29sZSIsImxvZyIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlRGVsZXRlIiwiYmxvZ09iamVjdCIsInJlbW92ZSIsImJsb2dJbmRleCIsImZpbHRlciIsImJsb2ciLCJpZCIsInVwZGF0ZWRCbG9ncyIsImVycm9yIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImNsZWFyIiwiaGFuZGxlQWRkQmxvZyIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmVzcG9uc2VCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwibWVzc2FnZSIsImhhbmRsZUFkZExpa2UiLCJ1cGRhdGVkQmxvZyIsImFkZExpa2UiLCJpbmRleCIsImZpbmRJbmRleCIsImxvZ2luRm9ybSIsInRhcmdldCIsInZhbHVlIiwiZGlzcGxheUJsb2dzIiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJtYXAiLCJsb2dvdXRGb3JtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbi5qcydcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gnXG5cbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0uanN4J1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCdcblxuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCB7IHBvc3ROb3RpZmljYXRpb24gfSBmcm9tICcuL3JlZHVjZXJzL25vdGlmaWNhdGlvblJlZHVjZXIuanMnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpXG5cbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbigoYmxvZ3MpID0+IHNldEJsb2dzKGJsb2dzKSlcbiAgICBjb25zb2xlLmxvZyhibG9ncylcbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgLy8gY29uc29sZS5sb2coYFVzZXJuYW1lICR7dXNlcm5hbWV9IFxcblBhc3N3b3JkICR7cGFzc3dvcmR9YClcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLFxuICAgICAgICBwYXNzd29yZCxcbiAgICAgIH0pXG5cbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCd3cm9uZyBjcmVkZW50aWFscycpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgY29uc29sZS5sb2coJ2RlbGV0ZSB0cmlnZ2VyZWQnKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBibG9nU2VydmljZS5yZW1vdmUoYmxvZ09iamVjdClcbiAgICAgIGNvbnN0IGJsb2dJbmRleCA9IGJsb2dzLmZpbHRlcigoYmxvZykgPT4gYmxvZy5pZCA9PT0gYmxvZ09iamVjdC5pZClcbiAgICAgIGlmIChibG9nSW5kZXggIT09IC0xKSB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRCbG9ncyA9IGJsb2dzLmZpbHRlcigoYmxvZykgPT4gYmxvZy5pZCAhPT0gYmxvZ09iamVjdC5pZClcbiAgICAgICAgc2V0QmxvZ3ModXBkYXRlZEJsb2dzKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1NvbWUgYnV0IGhhcHBlbmVkIGRlbGV0aW5nIHRoZSBvYmplY3QgcHJvcGVybHknKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0Jsb2cgdW5hYmxlIHRvIGJlIGRlbGV0ZWQnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgICAgfSwgNTAwMClcbiAgICB9XG4gIH1cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5jbGVhcigpXG4gIH1cblxuICBjb25zdCBoYW5kbGVBZGRCbG9nID0gYXN5bmMgKGJsb2dPYmplY3QpID0+IHtcbiAgICBibG9nRm9ybVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZShibG9nT2JqZWN0KVxuXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmVzcG9uc2VCbG9nKSlcblxuICAgICAgZGlzcGF0Y2gocG9zdE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdBIG5ldyBibG9nIHdhcyBhZGRlZCEnIH0pKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgZGlzcGF0Y2gocG9zdE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdCbG9nIHVuYWJsZSB0byBiZSBwb3N0ZWQnIH0pKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUFkZExpa2UgPSBhc3luYyAoYmxvZ09iamVjdCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmFkZExpa2UoYmxvZ09iamVjdClcbiAgICAgIGNvbnN0IGluZGV4ID0gYmxvZ3MuZmluZEluZGV4KChibG9nKSA9PiBibG9nLmlkID09PSB1cGRhdGVkQmxvZy5pZClcblxuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICBjb25zdCB1cGRhdGVkQmxvZ3MgPSBbLi4uYmxvZ3NdXG4gICAgICAgIHVwZGF0ZWRCbG9nc1tpbmRleF0gPSB1cGRhdGVkQmxvZ1xuICAgICAgICBzZXRCbG9ncyh1cGRhdGVkQmxvZ3MpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvL3Rocm93IGVycm9yXG4gICAgICAgIHRocm93IGVycm9yTWVzc2FnZSgnRXJyb3IgaW4gYWRkaW5nIGxpa2UgdG8gYmxvZycpXG4gICAgICAgIC8vIGRpc3BhdGNoKHBvc3ROb3RpZmljYXRpb24oeyBtZXNzYWdlOiAnRXJyb3I6IHVuYWJsZSB0byBhZGQgbGlrZScgfSkpXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGRpc3BhdGNoKHBvc3ROb3RpZmljYXRpb24oeyBtZXNzYWdlOiAnRXJyb3I6IHVuYWJsZSB0byBhZGQgbGlrZScgfSkpXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbiBhZGRpbmcgbGlrZSB0byBibG9nJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBsb2dpbkZvcm0gPSAoKSA9PiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5Mb2dpbiBGb3JtPC9oMj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgdXNlcm5hbWVcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgdHlwZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgIG5hbWU9eydVc2VybmFtZSd9XG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG5hbWU9eydQYXNzd29yZCd9XG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gZGF0YS10ZXN0aWQ9XCJsb2dpbkJ1dHRvblwiIHR5cGU9XCJzdWJtaXRcIj5cbiAgICAgICAgICBsb2dpblxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IGRpc3BsYXlCbG9ncyA9ICgpID0+IChcbiAgICA8ZGl2PlxuICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgIHtibG9nc1xuICAgICAgICAuc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpIC8vc29ydCBoZXJlLCAtMSBtZWFucyBwdXQgYSBmaXJzdCwgMSBtZWFucyBwdXQgYiBmaXJzdFxuICAgICAgICAubWFwKChibG9nKSA9PiAoXG4gICAgICAgICAgPEJsb2dcbiAgICAgICAgICAgIGtleT17YmxvZy5pZH1cbiAgICAgICAgICAgIGJsb2c9e2Jsb2d9XG4gICAgICAgICAgICBoYW5kbGVBZGRMaWtlPXtoYW5kbGVBZGRMaWtlfVxuICAgICAgICAgICAgaGFuZGxlRGVsZXRlPXtoYW5kbGVEZWxldGV9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSl9XG4gICAgPC9kaXY+XG4gIClcblxuICBjb25zdCBsb2dvdXRGb3JtID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9nb3V0fT5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+TG9nb3V0PC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8Tm90aWZpY2F0aW9uIC8+XG4gICAgICB7dXNlciA/IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwibmV3IGJsb2dcIiByZWY9e2Jsb2dGb3JtUmVmfT5cbiAgICAgICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXtoYW5kbGVBZGRCbG9nfSAvPlxuICAgICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgICAgIHtkaXNwbGF5QmxvZ3MoKX1cbiAgICAgICAgICB7bG9nb3V0Rm9ybSgpfVxuICAgICAgICA8Lz5cbiAgICAgICkgOiAoXG4gICAgICAgIGxvZ2luRm9ybSgpXG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuXG4vL21ha2UgbGluZSAxMzkgdG9nZ2xlIGFibGVcbiJdLCJmaWxlIjoiL1VzZXJzL3VzZXIvRGVza3RvcC9mdWxsU3RhY2svNy1Sb3V0ZXItQ29zdHVtSG9va3MtQ1NTLVdlYnBhY2svNy4xMC1SZWR1eC1SZWZhY3Rvci9mcm9udGVuZC9zcmMvQXBwLmpzeCJ9