import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b7f440bf"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b7f440bf"; const useRef = __vite__cjsImport3_react["useRef"];
import Togglable from "/src/components/Togglable.jsx";
const Blog = ({
  blog,
  handleAddLike,
  handleDelete
}) => {
  _s();
  const blogRef = useRef();
  console.log(blog);
  return /* @__PURE__ */ jsxDEV("div", { "data-testid": "aBlogPost", children: [
    blog.title,
    /* @__PURE__ */ jsxDEV("div", { "data-testid": "postAuthor", children: [
      " ",
      blog.author,
      " "
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "view", ref: blogRef, children: [
      blog.url,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { "data-testid": "postLikes", children: [
        " Likes: ",
        blog.likes,
        " "
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => handleAddLike(blog), children: " Like!" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      blog.user.name,
      " ",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 32,
        columnNumber: 26
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(blog), children: "Delete" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      " ",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
        lineNumber: 33,
        columnNumber: 68
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(Blog, "T2ywM5bglr4si24rjN/G5f9VB/Q=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CTixTQUFTQSxjQUFjO0FBQ3ZCLE9BQU9DLGVBQWU7QUFHdEIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQWVDO0FBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RELFFBQU1DLFVBQVVQLE9BQU87QUFDdkJRLFVBQVFDLElBQUlOLElBQUk7QUFVaEIsU0FDRSx1QkFBQyxTQUFJLGVBQVksYUFDZEE7QUFBQUEsU0FBS087QUFBQUEsSUFDTix1QkFBQyxTQUFJLGVBQVksY0FBYTtBQUFBO0FBQUEsTUFBRVAsS0FBS1E7QUFBQUEsTUFBTztBQUFBLFNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxJQUM3Qyx1QkFBQyxhQUFVLGFBQVksUUFBTyxLQUFLSixTQUNoQ0o7QUFBQUEsV0FBS1M7QUFBQUEsTUFDTix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsdUJBQUMsU0FBSSxlQUFZLGFBQVk7QUFBQTtBQUFBLFFBQVNULEtBQUtVO0FBQUFBLFFBQU07QUFBQSxXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsTUFDbEQsdUJBQUMsWUFBTyxTQUFTLE1BQU1ULGNBQWNELElBQUksR0FBRyxzQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDRkEsS0FBS1csS0FBS0M7QUFBQUEsTUFBSztBQUFBLE1BQUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNwQix1QkFBQyxZQUFPLFNBQVMsTUFBTVYsYUFBYUYsSUFBSSxHQUFHLHNCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFBUztBQUFBLE1BQUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxTQVBoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBRUFHLEdBN0JNSixNQUFJO0FBQUFjLEtBQUpkO0FBK0JOLGVBQWVBO0FBRWYsSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVJlZiIsIlRvZ2dsYWJsZSIsIkJsb2ciLCJibG9nIiwiaGFuZGxlQWRkTGlrZSIsImhhbmRsZURlbGV0ZSIsIl9zIiwiYmxvZ1JlZiIsImNvbnNvbGUiLCJsb2ciLCJ0aXRsZSIsImF1dGhvciIsInVybCIsImxpa2VzIiwidXNlciIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL1RvZ2dsYWJsZS5qc3gnXG4vLyBpbXBvcnQgYmxvZ1NlcnZpY2VzIGZyb20gXCIuLi9zZXJ2aWNlcy9ibG9ncy5qc1wiXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCBoYW5kbGVBZGRMaWtlLCBoYW5kbGVEZWxldGUgfSkgPT4ge1xuICBjb25zdCBibG9nUmVmID0gdXNlUmVmKClcbiAgY29uc29sZS5sb2coYmxvZylcblxuICAvLyBjb25zdCBoYW5kbGVBZGRMaWtlID0gYXN5bmMgKGlkKSA9PiB7XG4gIC8vICAgICB0cnkge1xuICAvLyAgICAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlcy5hZGRMaWtlKGlkKVxuICAvLyAgICAgfWNhdGNoIChlcnJvcil7XG4gIC8vICAgICAgICAgY29uc29sZS5lcnJvcihcImVycm9yIGluIGFkZGluZyBsaWtlIHRvIGJsb2dcIilcbiAgLy8gICAgIH1cbiAgLy8gfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBkYXRhLXRlc3RpZD1cImFCbG9nUG9zdFwiPlxuICAgICAge2Jsb2cudGl0bGV9XG4gICAgICA8ZGl2IGRhdGEtdGVzdGlkPVwicG9zdEF1dGhvclwiPiB7YmxvZy5hdXRob3J9IDwvZGl2PlxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cInZpZXdcIiByZWY9e2Jsb2dSZWZ9PlxuICAgICAgICB7YmxvZy51cmx9XG4gICAgICAgIDxiciAvPlxuICAgICAgICA8ZGl2IGRhdGEtdGVzdGlkPVwicG9zdExpa2VzXCI+IExpa2VzOiB7YmxvZy5saWtlc30gPC9kaXY+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQWRkTGlrZShibG9nKX0+IExpa2UhPC9idXR0b24+XG4gICAgICAgIDxiciAvPlxuICAgICAgICB7YmxvZy51c2VyLm5hbWV9IDxiciAvPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShibG9nKX0+RGVsZXRlPC9idXR0b24+IDxiciAvPlxuICAgICAgPC9Ub2dnbGFibGU+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuLy9uZWVkIHRvIGFkZCB1c2VybmFtZSBmb3IgNS45XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dcblxuLy9tYWtlIGl0IHNvIG9uIGNsaWNrIGxpa2VzIGdvIHVwXG4iXSwiZmlsZSI6Ii9Vc2Vycy91c2VyL0Rlc2t0b3AvZnVsbFN0YWNrLzctUm91dGVyLUNvc3R1bUhvb2tzLUNTUy1XZWJwYWNrLzcuMTAtUmVkdXgtUmVmYWN0b3IvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==