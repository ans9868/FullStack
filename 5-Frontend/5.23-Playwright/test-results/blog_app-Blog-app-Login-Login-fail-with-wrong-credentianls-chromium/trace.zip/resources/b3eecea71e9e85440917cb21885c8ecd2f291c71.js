import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b7f440bf"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useSelector, useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=b7f440bf";
import { clearNotification } from "/src/reducers/notificationReducer.js?t=1719892586307";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=b7f440bf"; const useEffect = __vite__cjsImport5_react["useEffect"];
import { current } from "/node_modules/.vite/deps/@reduxjs_toolkit.js?v=b7f440bf";
const Notification = () => {
  _s();
  const notification = useSelector((state) => state.notification);
  const dispatch = useDispatch();
  console.log("notif:" + notification.message);
  console.log("visib:" + notification.visible);
  console.log("duration:" + notification.duration);
  useEffect(() => {
    if (notification.visible) {
      const timer = setTimeout(() => {
        dispatch(clearNotification());
      }, notification.duration || 5e3);
      console.log(`Notification posted for: ${notification.duration}`);
      return () => clearTimeout(timer);
    }
  }, [notification, dispatch]);
  const style = {
    border: "solid",
    padding: 10,
    borderWidth: 1,
    display: notification.visible ? "block" : "none"
  };
  return /* @__PURE__ */ jsxDEV("div", { style, children: notification.message }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Notification.jsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
};
_s(Notification, "gpWMF6xKOYzR0GlqhE+/u0p8sb4=", false, function() {
  return [useSelector, useDispatch];
});
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JTOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9CVCxTQUFTQSxhQUFhQyxtQkFBbUI7QUFDekMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNQyxlQUFlUCxZQUFhUSxXQUFVQSxNQUFNRCxZQUFZO0FBQzlELFFBQU1FLFdBQVdSLFlBQVk7QUFFN0JTLFVBQVFDLElBQUksV0FBV0osYUFBYUssT0FBTztBQUMzQ0YsVUFBUUMsSUFBSSxXQUFXSixhQUFhTSxPQUFPO0FBQzNDSCxVQUFRQyxJQUFJLGNBQWNKLGFBQWFPLFFBQVE7QUFFL0NYLFlBQVUsTUFBTTtBQUNkLFFBQUlJLGFBQWFNLFNBQVM7QUFDeEIsWUFBTUUsUUFBUUMsV0FBVyxNQUFNO0FBQzdCUCxpQkFBU1Asa0JBQWtCLENBQUM7QUFBQSxNQUM5QixHQUFHSyxhQUFhTyxZQUFZLEdBQUk7QUFDaENKLGNBQVFDLElBQUssNEJBQTJCSixhQUFhTyxRQUFTLEVBQUM7QUFFL0QsYUFBTyxNQUFNRyxhQUFhRixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ1IsY0FBY0UsUUFBUSxDQUFDO0FBRTNCLFFBQU1TLFFBQVE7QUFBQSxJQUNaQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxJQUNiQyxTQUFTZixhQUFhTSxVQUFVLFVBQVU7QUFBQSxFQUM1QztBQUVBLFNBQU8sdUJBQUMsU0FBSSxPQUFlTix1QkFBYUssV0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QztBQUNsRDtBQUFDTixHQTNCS0QsY0FBWTtBQUFBLFVBQ0tMLGFBQ0pDLFdBQVc7QUFBQTtBQUFBc0IsS0FGeEJsQjtBQTZCTixlQUFlQTtBQUFZLElBQUFrQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU2VsZWN0b3IiLCJ1c2VEaXNwYXRjaCIsImNsZWFyTm90aWZpY2F0aW9uIiwidXNlRWZmZWN0IiwiY3VycmVudCIsIk5vdGlmaWNhdGlvbiIsIl9zIiwibm90aWZpY2F0aW9uIiwic3RhdGUiLCJkaXNwYXRjaCIsImNvbnNvbGUiLCJsb2ciLCJtZXNzYWdlIiwidmlzaWJsZSIsImR1cmF0aW9uIiwidGltZXIiLCJzZXRUaW1lb3V0IiwiY2xlYXJUaW1lb3V0Iiwic3R5bGUiLCJib3JkZXIiLCJwYWRkaW5nIiwiYm9yZGVyV2lkdGgiLCJkaXNwbGF5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNlbGVjdG9yLCB1c2VEaXNwYXRjaCB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHsgY2xlYXJOb3RpZmljYXRpb24gfSBmcm9tICcuLi9yZWR1Y2Vycy9ub3RpZmljYXRpb25SZWR1Y2VyLmpzJ1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjdXJyZW50IH0gZnJvbSAnQHJlZHV4anMvdG9vbGtpdCdcblxuY29uc3QgTm90aWZpY2F0aW9uID0gKCkgPT4ge1xuICBjb25zdCBub3RpZmljYXRpb24gPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLm5vdGlmaWNhdGlvbilcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpXG5cbiAgY29uc29sZS5sb2coJ25vdGlmOicgKyBub3RpZmljYXRpb24ubWVzc2FnZSlcbiAgY29uc29sZS5sb2coJ3Zpc2liOicgKyBub3RpZmljYXRpb24udmlzaWJsZSlcbiAgY29uc29sZS5sb2coJ2R1cmF0aW9uOicgKyBub3RpZmljYXRpb24uZHVyYXRpb24pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAobm90aWZpY2F0aW9uLnZpc2libGUpIHtcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGRpc3BhdGNoKGNsZWFyTm90aWZpY2F0aW9uKCkpXG4gICAgICB9LCBub3RpZmljYXRpb24uZHVyYXRpb24gfHwgNTAwMClcbiAgICAgIGNvbnNvbGUubG9nKGBOb3RpZmljYXRpb24gcG9zdGVkIGZvcjogJHtub3RpZmljYXRpb24uZHVyYXRpb259YClcbiAgICAgIC8vcmVzZXRzIHRoZSB0aW1lciBpZiBhbnkgb2YgdGhlIGRlcGVuZGVuY2llcyBpZSBhIG5ldyBub3RpZmljYXRpb24gcHJvbXB0IGNvbWVzIHVwXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKVxuICAgIH1cbiAgfSwgW25vdGlmaWNhdGlvbiwgZGlzcGF0Y2hdKVxuXG4gIGNvbnN0IHN0eWxlID0ge1xuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBwYWRkaW5nOiAxMCxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBkaXNwbGF5OiBub3RpZmljYXRpb24udmlzaWJsZSA/ICdibG9jaycgOiAnbm9uZScsXG4gIH1cblxuICByZXR1cm4gPGRpdiBzdHlsZT17c3R5bGV9Pntub3RpZmljYXRpb24ubWVzc2FnZX08L2Rpdj5cbn1cblxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uXG4iXSwiZmlsZSI6Ii9Vc2Vycy91c2VyL0Rlc2t0b3AvZnVsbFN0YWNrLzctUm91dGVyLUNvc3R1bUhvb2tzLUNTUy1XZWJwYWNrLzcuMTAtUmVkdXgtUmVmYWN0b3IvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9