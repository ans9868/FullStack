import { configureStore } from "/node_modules/.vite/deps/@reduxjs_toolkit.js?v=b7f440bf"
import notificationReducer from "/src/reducers/notificationReducer.js?t=1719892586307"

const store = configureStore({
  reducer: {
    notification: notificationReducer,
  },
})

export default store
