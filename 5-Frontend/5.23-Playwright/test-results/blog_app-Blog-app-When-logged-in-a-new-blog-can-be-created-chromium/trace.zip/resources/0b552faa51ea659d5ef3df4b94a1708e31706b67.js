import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b7f440bf"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b7f440bf"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: !visible ? "none" : ""
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/7-Router-CostumHooks-CSS-Webpack/7.10-Redux-Refactor/frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CUixTQUFTQSxVQUFVQyxxQkFBcUJDLGtCQUFrQjtBQUUxRCxNQUFNQyxZQUFTQyxHQUFHRixXQUFVRyxLQUFBRCxHQUFDLENBQUNFLE9BQU9DLFFBQVE7QUFBQUgsS0FBQTtBQUMzQyxRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSVQsU0FBUyxLQUFLO0FBRTVDLFFBQU1VLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBUyxDQUFDSCxVQUFVLFNBQVM7QUFBQSxFQUFHO0FBRTFELFFBQU1LLG1CQUFtQkEsTUFBTTtBQUM3QkosZUFBVyxDQUFDRCxPQUFPO0FBQUEsRUFDckI7QUFFQVAsc0JBQW9CTSxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQUVNO0FBQUFBLElBQWlCO0FBQUEsRUFDNUIsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0gsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJQLGdCQUFNUSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPRixpQkFDVE47QUFBQUEsWUFBTVM7QUFBQUEsTUFDUCx1QkFBQyxZQUFPLFNBQVNGLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUosR0FBQyxrQ0FBQztBQUFBRyxNQXpCSWI7QUEyQk4sZUFBZUE7QUFBUyxJQUFBRSxJQUFBVztBQUFBQyxhQUFBWixJQUFBO0FBQUFZLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJmb3J3YXJkUmVmIiwiVG9nZ2xhYmxlIiwiX3MiLCJfYyIsInByb3BzIiwicmVmIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImJ1dHRvbkxhYmVsIiwiY2hpbGRyZW4iLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VJbXBlcmF0aXZlSGFuZGxlLCBmb3J3YXJkUmVmIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IFRvZ2dsYWJsZSA9IGZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6ICF2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgc2V0VmlzaWJsZSghdmlzaWJsZSlcbiAgfVxuXG4gIHVzZUltcGVyYXRpdmVIYW5kbGUocmVmLCAoKSA9PiB7XG4gICAgcmV0dXJuIHsgdG9nZ2xlVmlzaWJpbGl0eSB9XG4gIH0pXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBzdHlsZT17aGlkZVdoZW5WaXNpYmxlfT5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57cHJvcHMuYnV0dG9uTGFiZWx9PC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59KVxuXG5leHBvcnQgZGVmYXVsdCBUb2dnbGFibGVcbiJdLCJmaWxlIjoiL1VzZXJzL3VzZXIvRGVza3RvcC9mdWxsU3RhY2svNy1Sb3V0ZXItQ29zdHVtSG9va3MtQ1NTLVdlYnBhY2svNy4xMC1SZWR1eC1SZWZhY3Rvci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2dnbGFibGUuanN4In0=