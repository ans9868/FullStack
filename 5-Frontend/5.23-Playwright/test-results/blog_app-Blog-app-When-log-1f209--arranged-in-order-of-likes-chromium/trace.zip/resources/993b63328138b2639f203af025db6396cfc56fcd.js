import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13f88573"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=13f88573"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const Notification = ({
  message
}) => {
  if (message === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "error", children: message }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/Notification.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_c = Notification;
Notification.PropTypes = {
  message: PropTypes.string.isRequired
};
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7QUFSSixPQUFPQSxvQkFBZTtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVsQyxNQUFNQyxlQUFlQSxDQUFDO0FBQUEsRUFBRUM7QUFBUSxNQUFNO0FBQ3BDLE1BQUlBLFlBQVksTUFBTTtBQUNwQixXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFXLFNBQ2JBLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBVktGO0FBWU5BLGFBQWFELFlBQVk7QUFBQSxFQUN2QkUsU0FBU0YsVUFBVUksT0FBT0M7QUFDNUI7QUFFQSxlQUFlSjtBQUFZLElBQUFFO0FBQUFHLGFBQUFILElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJOb3RpZmljYXRpb24iLCJtZXNzYWdlIiwiX2MiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UgfSkgPT4ge1xuICBpZiAobWVzc2FnZSA9PT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXsnZXJyb3InfT5cbiAgICAgIHttZXNzYWdlfVxuICAgIDwvZGl2PlxuICApXG59XG5cbk5vdGlmaWNhdGlvbi5Qcm9wVHlwZXMgPSB7XG4gIG1lc3NhZ2U6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6Ii9Vc2Vycy91c2VyL0Rlc2t0b3AvZnVsbFN0YWNrLzUtRnJvbnRlbmQvNS4xMi1CbG9nLUxpc3QtRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9