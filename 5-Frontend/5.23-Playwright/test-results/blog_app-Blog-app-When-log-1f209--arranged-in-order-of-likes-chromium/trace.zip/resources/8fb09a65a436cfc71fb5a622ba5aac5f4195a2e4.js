import axios from "/node_modules/.vite/deps/axios.js?v=13f88573"
const baseUrl = '/api/login'

const login = async credentials => {
  const response = await axios.post(baseUrl, credentials)
  return response.data
}

export default { login }