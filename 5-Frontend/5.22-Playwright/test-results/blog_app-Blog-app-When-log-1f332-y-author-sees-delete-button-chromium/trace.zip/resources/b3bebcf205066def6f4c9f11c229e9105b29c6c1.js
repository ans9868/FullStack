import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13f88573"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=13f88573"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [title, setTitle] = useState([]);
  const [author, setAuthor] = useState([]);
  const [URL, setURL] = useState([]);
  const addBLog = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url: URL,
      likes: 0
    });
    setTitle("");
    setAuthor("");
    setURL("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Add Blog" }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBLog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: title, name: "Title", onChange: ({
          target
        }) => setTitle(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
          lineNumber: 28,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "author",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "author", type: "text", value: author, name: "Author", onChange: ({
          target
        }) => setAuthor(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
          lineNumber: 35,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "url",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "url", type: "text", value: URL, name: "URL", onChange: ({
          target
        }) => setURL(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
          lineNumber: 42,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "tDFOm9vMvGBGbKkrxxXKvMBLkSU=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBRW5DLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJTCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDTSxRQUFRQyxTQUFTLElBQUlQLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNRLEtBQUtDLE1BQU0sSUFBSVQsU0FBUyxFQUFFO0FBRWpDLFFBQU1VLFVBQVdDLFdBQVc7QUFDMUJBLFVBQU1DLGVBQWU7QUFDckJWLGVBQVc7QUFBQSxNQUNURTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBTyxLQUFLTDtBQUFBQSxNQUNMTSxPQUFPO0FBQUEsSUFDVCxDQUFDO0FBRURULGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsd0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxVQUFLLFVBQVVDLFNBQ2Q7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsZUFBWSxZQUNaLE1BQUssUUFDTCxPQUFPTixPQUNQLE1BQU0sU0FDTixVQUFVLENBQUM7QUFBQSxVQUFFVztBQUFBQSxRQUFPLE1BQU1WLFNBQVNVLE9BQU9DLEtBQUssS0FMakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUttRDtBQUFBLFdBUHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRix1QkFBQyxXQUNDLGVBQVksVUFDWixNQUFLLFFBQ0wsT0FBT1YsUUFDUCxNQUFNLFVBQ04sVUFBVSxDQUFDO0FBQUEsVUFBRVM7QUFBQUEsUUFBTyxNQUFNUixVQUFVUSxPQUFPQyxLQUFLLEtBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLb0Q7QUFBQSxXQVB0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxlQUFZLE9BQ1osTUFBSyxRQUNMLE9BQU9SLEtBQ1AsTUFBTSxPQUNOLFVBQVUsQ0FBQztBQUFBLFVBQUVPO0FBQUFBLFFBQU8sTUFBTU4sT0FBT00sT0FBT0MsS0FBSyxLQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2lEO0FBQUEsV0FQbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBbEM5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsT0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNiLEdBN0RLRixVQUFRO0FBQUFnQixLQUFSaEI7QUErRE4sZUFBZUE7QUFBUSxJQUFBZ0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwiVVJMIiwic2V0VVJMIiwiYWRkQkxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ1cmwiLCJsaWtlcyIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZ0Zvcm0gPSAoeyBjcmVhdGVCbG9nIH0pID0+IHtcbiAgLy9jcmVhdGVCbG9nIGFzIGlucHV0XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW1VSTCwgc2V0VVJMXSA9IHVzZVN0YXRlKFtdKVxuXG4gIGNvbnN0IGFkZEJMb2cgPSAoZXZlbnQpID0+ICB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNyZWF0ZUJsb2coe1xuICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgYXV0aG9yOiBhdXRob3IsXG4gICAgICB1cmw6IFVSTCxcbiAgICAgIGxpa2VzOiAwXG4gICAgfSlcblxuICAgIHNldFRpdGxlKCcnKVxuICAgIHNldEF1dGhvcignJylcbiAgICBzZXRVUkwoJycpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+QWRkIEJsb2c8L2gyPlxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2FkZEJMb2d9PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VzZXJuYW1lJ1xuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgbmFtZT17J1RpdGxlJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VGl0bGUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBhdXRob3JcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSdhdXRob3InXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxuICAgICAgICAgICAgbmFtZT17J0F1dGhvcid9XG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldEF1dGhvcih0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHVybFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VybCdcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHZhbHVlPXtVUkx9XG4gICAgICAgICAgICBuYW1lPXsnVVJMJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VVJMKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+Y3JlYXRlPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6Ii9Vc2Vycy91c2VyL0Rlc2t0b3AvZnVsbFN0YWNrLzUtRnJvbnRlbmQvNS4xMi1CbG9nLUxpc3QtRnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0Zvcm0uanN4In0=