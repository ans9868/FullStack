import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=13f88573"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=13f88573"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1716753789472";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx";
import BlogForm from "/src/components/BlogForm.jsx?t=1716682104775";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [positiveMessage, setPositiveMessage] = useState(null);
  const blogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
    console.log(blogs);
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("wrong credentials");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleDelete = async (blogObject) => {
    console.log("delete triggered");
    try {
      await blogService.remove(blogObject);
      const blogIndex = blogs.filter((blog) => blog.id === blogObject.id);
      if (blogIndex !== -1) {
        const updatedBlogs = blogs.filter((blog) => blog.id !== blogObject.id);
        setBlogs(updatedBlogs);
      } else {
        console.log("Some but happened deleting the object properly");
      }
    } catch (error) {
      setErrorMessage("Blog unable to be deleted");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLogout = async (event) => {
    window.localStorage.removeItem("loggedBlogappUser");
    window.localStorage.clear();
  };
  const handleAddBlog = async (blogObject) => {
    blogFormRef.current.toggleVisibility();
    try {
      const responseBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(responseBlog));
      setPositiveMessage("A new blog was added!");
      setTimeout(() => {
        setPositiveMessage(null);
      }, 5e3);
    } catch (exception) {
      setErrorMessage("Blog unable to be posted");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleAddLike = async (blogObject) => {
    try {
      const updatedBlog = await blogService.addLike(blogObject);
      const index = blogs.findIndex((blog) => blog.id === updatedBlog.id);
      if (index !== -1) {
        const updatedBlogs = [...blogs];
        updatedBlogs[index] = updatedBlog;
        setBlogs(updatedBlogs);
      } else {
        setErrorMessage("Unable to give like to the blog");
        setTimeout(() => {
          setErrorMessage(null);
        }, 5e3);
      }
    } catch (error) {
      console.error("error in adding like to blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login Form" }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "username", value: username, name: "Username", onChange: ({
          target
        }) => setUsername(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, name: "Password", onChange: ({
          target
        }) => setPassword(target.value) }, void 0, false, {
          fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
          lineNumber: 120,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { "data-testid": "loginButton", type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
        lineNumber: 124,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 109,
    columnNumber: 27
  }, this);
  const displayBlogs = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    blogs.sort((a, b) => a.likes > b.likes ? -1 : 1).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, handleAddLike, handleDelete }, blog.id, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 130,
      columnNumber: 18
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 127,
    columnNumber: 30
  }, this);
  const logoutForm = () => /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogout, children: /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Logout" }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 134,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 133,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 132,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 138,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: positiveMessage }, void 0, false, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 139,
      columnNumber: 7
    }, this),
    user ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: handleAddBlog }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
        lineNumber: 142,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
        lineNumber: 141,
        columnNumber: 11
      }, this),
      displayBlogs(),
      logoutForm()
    ] }, void 0, true, {
      fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
      lineNumber: 140,
      columnNumber: 15
    }, this) : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx",
    lineNumber: 137,
    columnNumber: 10
  }, this);
};
_s(App, "+vCJKDtqW5BrpvQhQecDvyC/xIg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/user/Desktop/fullStack/5-Frontend/5.12-Blog-List-Frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUlNLFNBa0RFLFVBbERGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpJTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFFekIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVosU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ21CLGNBQWNDLGVBQWUsSUFBSXBCLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNxQixpQkFBaUJDLGtCQUFrQixJQUFJdEIsU0FBUyxJQUFJO0FBSTNELFFBQU11QixjQUFjckIsT0FBTztBQUczQkQsWUFBVSxNQUFNO0FBQ2RHLGdCQUFZb0IsT0FBTyxFQUFFQyxLQUFLZCxZQUN4QkMsU0FBVUQsTUFBTSxDQUNsQjtBQUNBZSxZQUFRQyxJQUFJaEIsS0FBSztBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMVixZQUFVLE1BQU07QUFDZCxVQUFNMkIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVgsUUFBT2UsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1YsY0FBUUQsS0FBSTtBQUNaYixrQkFBWThCLFNBQVNqQixNQUFLa0IsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1yQixRQUFPLE1BQU1aLGFBQWFrQyxNQUFNO0FBQUEsUUFDcEMxQjtBQUFBQSxRQUFVRTtBQUFBQSxNQUNaLENBQUM7QUFFRGMsYUFBT0MsYUFBYVUsUUFDbEIscUJBQXFCUixLQUFLUyxVQUFVeEIsS0FBSSxDQUMxQztBQUNBYixrQkFBWThCLFNBQVNqQixNQUFLa0IsS0FBSztBQUMvQmpCLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBUzBCLFdBQVc7QUFDbEJ0QixzQkFBZ0IsbUJBQW1CO0FBQ25DdUIsaUJBQVcsTUFBTTtBQUNmdkIsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFFBQU13QixlQUFlLE9BQVFDLGVBQWdCO0FBRTNDbkIsWUFBUUMsSUFBSSxrQkFBa0I7QUFDOUIsUUFBRztBQUNELFlBQU12QixZQUFZMEMsT0FBT0QsVUFBVTtBQUNuQyxZQUFNRSxZQUFZcEMsTUFBTXFDLE9BQU9DLFVBQVFBLEtBQUtDLE9BQU9MLFdBQVdLLEVBQUU7QUFDaEUsVUFBR0gsY0FBYyxJQUFHO0FBQ2xCLGNBQU1JLGVBQWV4QyxNQUFNcUMsT0FBT0MsVUFBUUEsS0FBS0MsT0FBT0wsV0FBV0ssRUFBRTtBQUNuRXRDLGlCQUFTdUMsWUFBWTtBQUFBLE1BQ3ZCLE9BQUs7QUFDSHpCLGdCQUFRQyxJQUFJLGdEQUFnRDtBQUFBLE1BQzlEO0FBQUEsSUFFRixTQUFTeUIsT0FBTztBQUNkaEMsc0JBQWdCLDJCQUEyQjtBQUMzQ3VCLGlCQUFXLE1BQU07QUFDZnZCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxRQUFNaUMsZUFBZSxPQUFPaEIsVUFBVTtBQUNwQ1IsV0FBT0MsYUFBYXdCLFdBQVcsbUJBQW1CO0FBQ2xEekIsV0FBT0MsYUFBYXlCLE1BQU07QUFBQSxFQUM1QjtBQUVBLFFBQU1DLGdCQUFnQixPQUFRWCxlQUFnQjtBQUM1Q3RCLGdCQUFZa0MsUUFBUUMsaUJBQWlCO0FBRXJDLFFBQUc7QUFDRCxZQUFNQyxlQUFlLE1BQU12RCxZQUFZd0QsT0FBT2YsVUFBVTtBQUV4RGpDLGVBQVNELE1BQU1rRCxPQUFPRixZQUFZLENBQUM7QUFDbkNyQyx5QkFBbUIsdUJBQXVCO0FBQzFDcUIsaUJBQVcsTUFBTTtBQUNmckIsMkJBQW1CLElBQUk7QUFBQSxNQUN6QixHQUFHLEdBQUk7QUFBQSxJQUVULFNBQVFvQixXQUFXO0FBQ2pCdEIsc0JBQWdCLDBCQUEwQjtBQUMxQ3VCLGlCQUFXLE1BQU07QUFDZnZCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEMsZ0JBQWdCLE9BQVFqQixlQUFnQjtBQUM1QyxRQUFJO0FBQ0YsWUFBTWtCLGNBQWMsTUFBTTNELFlBQVk0RCxRQUFRbkIsVUFBVTtBQUN4RCxZQUFNb0IsUUFBUXRELE1BQU11RCxVQUFVakIsVUFBUUEsS0FBS0MsT0FBT2EsWUFBWWIsRUFBRTtBQUVoRSxVQUFHZSxVQUFVLElBQUc7QUFDZCxjQUFNZCxlQUFlLENBQUMsR0FBR3hDLEtBQUs7QUFDOUJ3QyxxQkFBYWMsS0FBSyxJQUFJRjtBQUN0Qm5ELGlCQUFTdUMsWUFBWTtBQUFBLE1BQ3ZCLE9BQU07QUFDSi9CLHdCQUFnQixpQ0FBaUM7QUFDakR1QixtQkFBVyxNQUFNO0FBQ2Z2QiwwQkFBZ0IsSUFBSTtBQUFBLFFBQ3RCLEdBQUcsR0FBSTtBQUFBLE1BQ1Q7QUFBQSxJQUNGLFNBQVFnQyxPQUFNO0FBQ1oxQixjQUFRMEIsTUFBTSw4QkFBOEI7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZSxZQUFZQSxNQUNoQix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFVBQUssVUFBVS9CLGFBQ2Q7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsZUFBWSxZQUNaLE1BQUssWUFDTCxPQUFPdkIsVUFDUCxNQUFNLFlBQ04sVUFBVSxDQUFDO0FBQUEsVUFBRXVEO0FBQUFBLFFBQU8sTUFBTXRELFlBQVlzRCxPQUFPQyxLQUFLLEtBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLc0Q7QUFBQSxXQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxlQUFZLFlBQ1osTUFBSyxZQUNMLE9BQU90RCxVQUNQLE1BQU0sWUFDTixVQUFVLENBQUM7QUFBQSxVQUFFcUQ7QUFBQUEsUUFBTyxNQUFNcEQsWUFBWW9ELE9BQU9DLEtBQUssS0FMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtzRDtBQUFBLFdBUHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxlQUFZLGVBQWUsTUFBSyxVQUFTLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNEO0FBQUEsU0FyQnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxPQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBR0YsUUFBTUMsZUFBZUEsTUFDbkIsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDUDNELE1BQ0M0RCxLQUFLLENBQUNDLEdBQUdDLE1BQVFELEVBQUVFLFFBQVFELEVBQUVDLFFBQVEsS0FBSyxDQUFJLEVBQzlDQyxJQUNDMUIsVUFBUSx1QkFBQyxRQUFtQixNQUFZLGVBQThCLGdCQUFuREEsS0FBS0MsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RixDQUFPO0FBQUEsT0FMOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBR0YsUUFBTTBCLGFBQWFBLE1BQ2pCLHVCQUFDLFNBQ0MsaUNBQUMsVUFBSyxVQUFVdkIsY0FDZCxpQ0FBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFHRixTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxnQkFBYSxTQUFTbEMsZ0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUNwQyx1QkFBQyxnQkFBYSxTQUFTRSxtQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3RDSixPQUNDLG1DQUNFO0FBQUEsNkJBQUMsYUFBVSxhQUFZLFlBQVcsS0FBS00sYUFDckMsaUNBQUMsWUFBUyxZQUFZaUMsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ2MsYUFBYTtBQUFBLE1BQ2JNLFdBQVc7QUFBQSxTQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxJQUNFVCxVQUFVO0FBQUEsT0FYaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ3pELEdBcExLRCxLQUFHO0FBQUFvRSxLQUFIcEU7QUFzTE4sZUFBZUE7QUFFZixJQUFBb0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwiQmxvZ0Zvcm0iLCJUb2dnbGFibGUiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwicG9zaXRpdmVNZXNzYWdlIiwic2V0UG9zaXRpdmVNZXNzYWdlIiwiYmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwiY29uc29sZSIsImxvZyIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlRGVsZXRlIiwiYmxvZ09iamVjdCIsInJlbW92ZSIsImJsb2dJbmRleCIsImZpbHRlciIsImJsb2ciLCJpZCIsInVwZGF0ZWRCbG9ncyIsImVycm9yIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImNsZWFyIiwiaGFuZGxlQWRkQmxvZyIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmVzcG9uc2VCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwiaGFuZGxlQWRkTGlrZSIsInVwZGF0ZWRCbG9nIiwiYWRkTGlrZSIsImluZGV4IiwiZmluZEluZGV4IiwibG9naW5Gb3JtIiwidGFyZ2V0IiwidmFsdWUiLCJkaXNwbGF5QmxvZ3MiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsIm1hcCIsImxvZ291dEZvcm0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luLmpzJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCdcblxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybS5qc3gnXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUuanN4J1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbcG9zaXRpdmVNZXNzYWdlLCBzZXRQb3NpdGl2ZU1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbCkgLy9mb3IgY3JlYXRpbmcgbmV3IGJsb2cgLy8gY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShbXSlcbiAgLy8gY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKFtdKVxuICAvLyBjb25zdCBbVVJMLCBzZXRVUkxdID0gdXNlU3RhdGUoW10pXG5cbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICBzZXRCbG9ncyggYmxvZ3MgKVxuICAgIClcbiAgICBjb25zb2xlLmxvZyhibG9ncylcbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgLy8gY29uc29sZS5sb2coYFVzZXJuYW1lICR7dXNlcm5hbWV9IFxcblBhc3N3b3JkICR7cGFzc3dvcmR9YClcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLCBwYXNzd29yZCxcbiAgICAgIH0pXG5cbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcbiAgICAgICAgJ2xvZ2dlZEJsb2dhcHBVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCd3cm9uZyBjcmVkZW50aWFscycpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKCBibG9nT2JqZWN0ICkgPT4ge1xuXG4gICAgY29uc29sZS5sb2coJ2RlbGV0ZSB0cmlnZ2VyZWQnKVxuICAgIHRyeXtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnJlbW92ZShibG9nT2JqZWN0KVxuICAgICAgY29uc3QgYmxvZ0luZGV4ID0gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCA9PT0gYmxvZ09iamVjdC5pZClcbiAgICAgIGlmKGJsb2dJbmRleCAhPT0gLTEpe1xuICAgICAgICBjb25zdCB1cGRhdGVkQmxvZ3MgPSBibG9ncy5maWx0ZXIoYmxvZyA9PiBibG9nLmlkICE9PSBibG9nT2JqZWN0LmlkKVxuICAgICAgICBzZXRCbG9ncyh1cGRhdGVkQmxvZ3MpXG4gICAgICB9ZWxzZXtcbiAgICAgICAgY29uc29sZS5sb2coJ1NvbWUgYnV0IGhhcHBlbmVkIGRlbGV0aW5nIHRoZSBvYmplY3QgcHJvcGVybHknKVxuICAgICAgfVxuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnQmxvZyB1bmFibGUgdG8gYmUgZGVsZXRlZCcpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJylcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLmNsZWFyKClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUFkZEJsb2cgPSBhc3luYyAoIGJsb2dPYmplY3QgKSA9PiB7XG4gICAgYmxvZ0Zvcm1SZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcblxuICAgIHRyeXtcbiAgICAgIGNvbnN0IHJlc3BvbnNlQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZShibG9nT2JqZWN0KVxuXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmVzcG9uc2VCbG9nKSlcbiAgICAgIHNldFBvc2l0aXZlTWVzc2FnZSgnQSBuZXcgYmxvZyB3YXMgYWRkZWQhJylcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRQb3NpdGl2ZU1lc3NhZ2UobnVsbClcbiAgICAgIH0sIDUwMDApXG5cbiAgICB9Y2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCdCbG9nIHVuYWJsZSB0byBiZSBwb3N0ZWQnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgICAgfSwgNTAwMClcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVBZGRMaWtlID0gYXN5bmMgKCBibG9nT2JqZWN0ICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmFkZExpa2UoYmxvZ09iamVjdClcbiAgICAgIGNvbnN0IGluZGV4ID0gYmxvZ3MuZmluZEluZGV4KGJsb2cgPT4gYmxvZy5pZCA9PT0gdXBkYXRlZEJsb2cuaWQpXG5cbiAgICAgIGlmKGluZGV4ICE9PSAtMSl7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRCbG9ncyA9IFsuLi5ibG9nc11cbiAgICAgICAgdXBkYXRlZEJsb2dzW2luZGV4XSA9IHVwZGF0ZWRCbG9nXG4gICAgICAgIHNldEJsb2dzKHVwZGF0ZWRCbG9ncylcbiAgICAgIH1lbHNlIHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKCdVbmFibGUgdG8gZ2l2ZSBsaWtlIHRvIHRoZSBibG9nJylcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICAgIH0sIDUwMDApXG4gICAgICB9XG4gICAgfWNhdGNoIChlcnJvcil7XG4gICAgICBjb25zb2xlLmVycm9yKCdlcnJvciBpbiBhZGRpbmcgbGlrZSB0byBibG9nJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBsb2dpbkZvcm0gPSAoKSA9PiAgKFxuICAgIDxkaXY+XG4gICAgICA8aDI+TG9naW4gRm9ybTwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgICA8ZGl2PlxuICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3VzZXJuYW1lJ1xuICAgICAgICAgICAgdHlwZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgIG5hbWU9eydVc2VybmFtZSd9XG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgIHBhc3N3b3JkXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgbmFtZT17J1Bhc3N3b3JkJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nbG9naW5CdXR0b24nICB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IGRpc3BsYXlCbG9ncyA9ICgpID0+IChcbiAgICA8ZGl2PlxuICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgIHsgYmxvZ3NcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+ICggYS5saWtlcyA+IGIubGlrZXMgPyAtMSA6IDEgKSApIC8vc29ydCBoZXJlLCAtMSBtZWFucyBwdXQgYSBmaXJzdCwgMSBtZWFucyBwdXQgYiBmaXJzdFxuICAgICAgICAubWFwKFxuICAgICAgICAgIGJsb2cgPT4gPEJsb2cga2V5PXtibG9nLmlkfSBibG9nPXtibG9nfSBoYW5kbGVBZGRMaWtlPXtoYW5kbGVBZGRMaWtlfSBoYW5kbGVEZWxldGU9e2hhbmRsZURlbGV0ZX0gLz4gICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IGxvZ291dEZvcm0gPSAoKSA9PiAoXG4gICAgPGRpdj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dvdXR9PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5Mb2dvdXQ8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfS8+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e3Bvc2l0aXZlTWVzc2FnZX0vPlxuICAgICAge3VzZXIgPyAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD0nbmV3IGJsb2cnIHJlZj17YmxvZ0Zvcm1SZWZ9PlxuICAgICAgICAgICAgPEJsb2dGb3JtIGNyZWF0ZUJsb2c9e2hhbmRsZUFkZEJsb2d9Lz5cbiAgICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgICAgICB7ZGlzcGxheUJsb2dzKCl9XG4gICAgICAgICAge2xvZ291dEZvcm0oKX1cbiAgICAgICAgPC8+XG4gICAgICApIDogbG9naW5Gb3JtKCl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwXG5cbi8vbWFrZSBsaW5lIDEzOSB0b2dnbGUgYWJsZSJdLCJmaWxlIjoiL1VzZXJzL3VzZXIvRGVza3RvcC9mdWxsU3RhY2svNS1Gcm9udGVuZC81LjEyLUJsb2ctTGlzdC1Gcm9udGVuZC9zcmMvQXBwLmpzeCJ9